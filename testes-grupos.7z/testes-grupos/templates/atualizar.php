<?php
	include 'db.php';
	include 'colecionador_mock.php';
	$sql = "SELECT * FROM grupo WHERE id=$_GET[id]";
	
  	$con = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Atualizar Cliente</title>
	</head>
	<body>
		<h1>Atualizar Cliente</h1>
		<hr>
			<form method="post" action="">
				<?php if($dados = mysqli_fetch_array($con)) { ?>
				<table>
					<tr>
						<td>Nome do Grupo:</td>
						<td><input type="text" name="nome" value=<?php echo $dados['nome']; ?>></td>
					</tr>
					<tr>
						<td>Descrição:</td>
						<td><input type="text" name="descricao" value=<?php echo $dados['descricao']; ?>></td>
					</tr>
					<tr>
						<td>Adiministrdor:</td>
						<td>	<select name="colecionador_administrador">
							<?php
								for($i = 0; $i < count($colecionadores); $i++){

									$c = strval($colecionadores[$i]);
									echo "<option value=$c>$colecionadores[$i]</option>";
									}
							?>
							</select></td>
					</tr>
					<tr>
						<td>Data de criação:</td>
						<td><input type="text" name="data_de_criacaoairro" value=<?php echo $dados['data_de_criacao']; ?>></td>
					</tr>
				</table>

				<?php
					if(!empty($_POST['nome'])) {
						$nome 	= $_POST['nome'];
						$descricao 	= $_POST['descricao'];
						$administrador = $_POST['colecionador_administrador'];
						
						$id = $_GET['id'];
						
						var_dump($_POST);
						$sql = mysqli_prepare($conexao, "UPDATE grupo SET nome = ?, descricao = ?, colecionador_administrador = ? WHERE id=".$id);
						mysqli_stmt_bind_param($sql, 'sss', $nome, $descricao, $administrador);
				
						mysqli_stmt_execute($sql);
				
						header("Location: http://localhost/testes-grupos/templates/lista.php");
					}
				?>
				
				<input type="submit" value="Atualizar">
				<?php } ?>
			</form>
		<a href="lista.php"><input type="submit" value="voltar"></a>
	</body>
</html>