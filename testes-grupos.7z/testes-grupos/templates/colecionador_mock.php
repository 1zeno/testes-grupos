<?php 
$colecionadores = ["David","Carlos","Tarcisio"];

$descricaoM = ["Tudo na vida depende ", "Pare de tentar e comece a desistir",
 "No começo será dificil, mas no final dará errado"];

 $data = date("d/m/Y");
?>