<?php
    include 'db.php';
?>

<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">